#include <stdlib.h>
#include "answer01.h"

int arraySum(int * array, int len)
{
	return 0;
}

int arrayCountNegative(int * array, int len)
{
	return 0; 
}

int arrayIsIncreasing(int * array, int len)
{
	return 0;
}

int arrayIndexFind(int needle, const int * haystack, int len)
{
	return 0;
}

int arrayFindSmallest(int * array, int len)
{
	return 0;
}
